$(document).ready(function(){
  $('#title').focus();
    $('#text').autosize();
});

function getRandomNumber(minRange, maxRange) {
    return Math.floor(Math.random() * (maxRange + 1) + minRange);
}

window.onload = function() {
    const rando = getRandomNumber(14, 680);
    const rand = "SERVER ID: " + rando; 
    const leakz = 11 + " leaks available";
    const updated = "Last Updated: April, 1 2022";
    document.getElementById("yourNumber").innerHTML = rand;
    document.getElementById("leakNumber").innerHTML = leakz;
    document.getElementById("yourUpdated").innerHTML = updated;
};